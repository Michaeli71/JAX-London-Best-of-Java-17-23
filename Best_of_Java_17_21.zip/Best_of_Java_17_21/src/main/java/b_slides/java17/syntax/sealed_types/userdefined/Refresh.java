package b_slides.java17.syntax.sealed_types.userdefined;

import b_slides.java17.syntax.sealed_types.UserDefinedCommand;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Refresh extends UserDefinedCommand {
    @Override
    public void action() {
        System.out.println("Refresh");
    }
}