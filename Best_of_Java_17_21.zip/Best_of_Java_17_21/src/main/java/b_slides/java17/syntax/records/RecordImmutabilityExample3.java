package b_slides.java17.syntax.records;

import java.util.Date;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RecordImmutabilityExample3
{
    public static void main(final String[] args)
    {
		record DateRange(Date start, Date end) 
		{
			DateRange
			{
				if (!start.before(end))
					throw new IllegalArgumentException("start >= end");
			}
		}
				
		DateRange range1 = new DateRange(new Date(71,1,7), new Date(71,2,27));
		System.out.println(range1);
		
		range1.start.setTime(new Date(71,6,7).getTime());
		System.out.println(range1);	
    }
}
