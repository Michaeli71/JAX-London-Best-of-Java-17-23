package b_slides.java17.syntax.records;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RecordInterfaceExample2
{
    public static void main(String[] args) throws JsonProcessingException
    {
		record SimplePerson2(String name, int age, String city) implements Comparable<SimplePerson2>
		{
			@Override
			public int compareTo(SimplePerson2 other) 
			{				
				return name.compareTo(other.name);
			}
		}
		
		Set<SimplePerson2> speakers = new HashSet<>();
		speakers.add(new SimplePerson2("Michael", 51, "Zürich"));
		speakers.add(new SimplePerson2("Michael", 51, "Zürich"));
		// speakers.add(new SimplePerson2("Michael", 49, "Zürich"));
		speakers.add(new SimplePerson2("Anton", 42, "Aachen"));
		
		System.out.println(speakers);

        // -------------------
        
		Set<SimplePerson2> sortedSpeakers = new TreeSet<>();
		sortedSpeakers.add(new SimplePerson2("Michael", 51, "Zürich"));
		sortedSpeakers.add(new SimplePerson2("Michael", 51, "Zürich"));
		// sortedSpeakers.add(new SimplePerson2("Michael", 49, "Zürich"));
		sortedSpeakers.add(new SimplePerson2("Anton", 42, "Aachen"));
		   
		System.out.println(sortedSpeakers);
    }
}
