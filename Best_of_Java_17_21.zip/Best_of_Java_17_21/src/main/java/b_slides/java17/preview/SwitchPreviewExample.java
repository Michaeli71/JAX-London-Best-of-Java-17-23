package b_slides.java17.preview;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class SwitchPreviewExample {

	/*
	public static void main(String[] args) {
		
		processData("V1");
		processData("V2");
		processData(71);
		
		switchSupportingNull("Python");

		// not working in Eclipse?!
		switchSupportingNull(null);
	}

	static void switchSupportingNull(String str) {
		switch (str) {
		case null -> System.out.println("null is allowed in preview");
		case "Java", "Python" -> System.out.println("cool language");
		default -> System.out.println("everything else");
		}
	}

	static void processData(Object obj) {
		switch (obj) {
		case String str && str.startsWith("V1") -> System.out.println("Processing V1");
		case String str && str.startsWith("V2") -> System.out.println("Processing V2");
		case Integer i && i > 10 && i < 100 -> System.out.println("Processing ints");
		default -> throw new IllegalArgumentException("invalid input");
		}
	}
	*/
}

