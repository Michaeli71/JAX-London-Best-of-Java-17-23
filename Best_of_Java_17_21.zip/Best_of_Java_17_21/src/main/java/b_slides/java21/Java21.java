package b_slides.java21;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Java21 {

    public static void main(String[] args) {
        multiMatch("Python");
        multiMatch(null);
        multiMatch(7);

        // force exception
        record Person(String name, int age) {}
        multiMatch(new Person("Michael", 53));
    }

    static void multiMatch(Object obj) {
        switch (obj) {
            case null -> System.out.println("null");
            case String str when str.length() > 5 -> System.out.println(str.toUpperCase());
            case String str  -> System.out.println(str.toLowerCase());
            case Integer i -> System.out.println(i * i);
            default -> throw new IllegalArgumentException("Unsupported type " + obj.getClass());
        }
    }
}