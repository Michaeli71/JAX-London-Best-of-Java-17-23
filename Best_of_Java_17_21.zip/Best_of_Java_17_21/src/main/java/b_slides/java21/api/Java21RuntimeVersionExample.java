package b_slides.java21.api;

import javax.lang.model.SourceVersion;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Java21RuntimeVersionExample 
{
	public static void main(final String[] args)
	{
		System.out.println("Runtime required for this: " + 
	                       SourceVersion.RELEASE_21.runtimeVersion());
		System.out.println("latest: " + SourceVersion.latest());
		System.out.println("valueOf: " + SourceVersion.valueOf("RELEASE_21"));

		System.out.println(SourceVersion.latest().runtimeVersion());
		System.out.println(SourceVersion.latest().name());
	}
}