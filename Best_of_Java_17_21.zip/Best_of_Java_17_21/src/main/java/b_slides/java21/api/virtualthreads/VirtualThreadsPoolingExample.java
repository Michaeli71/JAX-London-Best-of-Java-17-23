package b_slides.java21.api.virtualthreads;
import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class VirtualThreadsPoolingExample
{
    public static void main(final String[] args)
    {
        for (int factorInThousands : Arrays.asList(5, 10, 15, 20, 25, 30, 35, 40))
        {
            try (var executor = Executors.newVirtualThreadPerTaskExecutor())
            {
                measureExecution(executor, "Virtual", factorInThousands);
            }

            try (var executor = Executors.newFixedThreadPool(5000))
            {
                measureExecution(executor, "Pooled Plattform", factorInThousands);
            }

            try (var executor = Executors.newCachedThreadPool())
            {
                measureExecution(executor, "Plattform", factorInThousands);
            }
        }
    }

private static void measureExecution(final ExecutorService executor,
                                     final String info, final int factor) {

    System.out.println("Start Measuring " + info);
    long start = System.nanoTime();

    try
    {
        for (int i = 0; i < factor; i++) {
            System.out.println("Start of " + info + " " + (i + 1) * 1000);
            submit1000Threads(executor);
        }
    }
    catch (Throwable th)
    {
        th.printStackTrace();
    }

    executor.close();
    System.out.println("End Measuring " + info);
    long end = System.nanoTime();
    System.out.println(info + " took " + (end-start) / 1_000_000 + " ms");
    System.out.println("-------------------------------");
}


    private static void submit1000Threads(ExecutorService executor) {
        for (int  i = 0; i < 1_000; i++)
        {
            final int pos = i;
            executor.submit(() -> {
                // Wenn man die Wartezeit hier kürzer wählt, hat man bei modernen
                // Prozessoren dann ggf. schin die ersten Threads abgearbeitet, bevor
                // die nächsten an den Executor übergeben werden
                Thread.sleep(Duration.ofSeconds(5));
                return pos;
            });
        }
    }
}
