package b_slides.java21.syntax.jep441_switch_pattern_matching;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class TypeInferenceInSwitchRecordPatternsExample {
    record TypedContainer<T1, T2>(T1 first, T2 second) {
    }

    public static void main(String[] args) {
    	recordInferenceOld(new TypedContainer<>("Michael", 52));
    	recordInferenceOld(new TypedContainer<>("Sophie", 2311));

        recordInferenceJdk20(new TypedContainer<>("Michaeli", 7));
        recordInferenceJdk20(new TypedContainer<>("Michael", 52));
        recordInferenceJdk20(new TypedContainer<>("Sophie", 2311));
    }

static void recordInferenceOld(TypedContainer<String, Integer> container) {
    switch (container) {
        case TypedContainer<String, Integer>(String text, var count) when text.contains("Michael") ->
            System.out.println(text + " is " + count + " years old");
        case TypedContainer<String, Integer>(var text, var count) -> System.out.println(text + count);
        default -> System.out.println("PENG");
    }
}

static void recordInferenceJdk20(TypedContainer<String, Integer> container) {
    switch (container) {
        case TypedContainer(var text, var count) when text.length() > 7 && count > 5 && count < 10 ->
                System.out.println("repeated " + text.repeat(count));
        case TypedContainer(var text, var count) when text.contains("Michael") ->
                System.out.println(text + " is " + count + " years old");
        case TypedContainer(var text, var count) -> System.out.println(text + count);
        default -> System.out.println("PENG");
    }
}
}
