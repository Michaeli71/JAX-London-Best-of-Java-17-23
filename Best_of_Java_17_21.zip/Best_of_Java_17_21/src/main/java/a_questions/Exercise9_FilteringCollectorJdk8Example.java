package a_questions;

import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toSet;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise9_FilteringCollectorJdk8Example 
{
	public static void main(final String[] args) 
	{
		final List<String> programming = List.of("Java", "JavaScript", "Groovy", "JavaFX", "Spring", "Java");
		
		final Stream<String> programmming1 = programming.stream();	
		final Set<String> result1 = programmming1.collect(Exercise9_CollectorsUtils.filtering(name -> name.contains("Java"), toSet()));
		System.out.println(result1);
		
		final Stream<String> programmming2 = programming.stream();	
		final Map<String, Long> result2 = programmming2.collect(groupingBy(i -> i, 
				Exercise9_CollectorsUtils.filtering(name -> name.contains("Java"), counting())));		
				
		System.out.println(result2);	

	}
}
