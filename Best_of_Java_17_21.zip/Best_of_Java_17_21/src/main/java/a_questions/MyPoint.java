package a_questions;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public record MyPoint(int x, int y) 
{ 
	public static void main(String[] args) {
			    
	    MyPoint point = new MyPoint(17, 19);
	    System.out.println(point);
        System.out.println("" + point.x + ", " + point.y());
        
        
	    MyPoint point2 = new MyPoint(17, 19);
	    if (point.equals(point2))
	    {
	    	System.out.println("GLEICHE WERTEBELEGUNG");
	    }
	    else
	    {
	    	System.out.println("NOT EQUAL");
	    }	    	
	}

	@Override
	public String toString() {
		return "[x: " + x + " / y: " + y + "]";
	}	
	
	/* DO NOT TRY IT AT HOME
	@Override
	public boolean equals(Object other) {
		return false;
	}
	*/
}
