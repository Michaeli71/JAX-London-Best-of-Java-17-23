package solutions.part2.exercise02;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Paths;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class ImageDownload
{
    public static void main(final String[] args) throws IOException, InterruptedException
    {
        var httpClient = HttpClient.newBuilder().build();
        URI uri = URI.create("https://imgs.xkcd.com/comics/modern_tools.png");
        var request = HttpRequest.newBuilder().GET().uri(uri).build();

        var downloadPath = Paths.get("./downloaded-modern_tools.png");
        var asFile = HttpResponse.BodyHandlers.ofFile(downloadPath);
        var response = httpClient.send(request, asFile);
        if (response.statusCode() == 200)
        {
            System.out.println("Content written to file: " + downloadPath.toAbsolutePath());
        }
    }
}