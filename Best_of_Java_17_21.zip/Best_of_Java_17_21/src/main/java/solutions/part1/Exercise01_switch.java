package solutions.part1;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise01_switch 
{
	public static void main(final String[] args)
	{
		int value = 7;

		dumbEvenOddChecker1a(value);
		
		String result1 = dumbEvenOddChecker1b(value);
		System.out.println("result1: " + result1);
		
		String result2 = dumbEvenOddChecker1cWithYield(value);
		System.out.println("result2: " + result2);
	}

	private static void dumbEvenOddChecker1a(final int value)
	{
		String result;

		switch (value)
		{
		   case 1, 3, 5, 7, 9 -> result = "odd";
		   case 0, 2, 4, 6, 8, 10 -> result = "even";
		   default -> result = "only implemented for values <= 10";
		}
		
		System.out.println("result: " + result);
	}

	private static String dumbEvenOddChecker1b(final int value)
	{
		return switch (value)
		{
			case 1, 3, 5, 7, 9 -> "odd";
			case 0, 2, 4, 6, 8, 10 -> "even";
			default -> "only implemented for values <= 10";
		};
	}
	
	private static String dumbEvenOddChecker1cWithYield(final int value) {
		return switch (value) {
			case 1, 3, 5, 7, 9:
				yield "odd";
			case 0, 2, 4, 6, 8, 10:
				yield "even";
			default:
				yield "only implemented for values <= 10";
		};
	}
}
