package solutions.part1;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise07_instanceof_Records_V1 
{
	// Verbesserung ohne Cast, aber instancoef verstösst gegen Open Closed
	public double computeArea(final Object figure) 
	{
		if (figure instanceof Square square) 
		{
			return square.sideLength * square.sideLength;
		} 
		else if (figure instanceof Circle circle) 
		{
			return circle.radius * circle.radius * Math.PI;
		}
		throw new IllegalArgumentException("figure is not a recognized figure");
	}
	
	record Square(double sideLength) {
	}
	
	record Circle(double radius) {
	}
}
