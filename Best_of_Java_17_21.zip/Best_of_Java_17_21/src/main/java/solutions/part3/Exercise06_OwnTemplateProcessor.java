package solutions.part3;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise06_OwnTemplateProcessor {

    public static void main(String[] args)
    {
        String name = "Michael";
        int age = 53;

        System.out.println(DOUBLE_BRACES."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(DOUBLE_BRACES_IMP."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(enclose(">>>", "<<<")."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(f."Hello, \{name}! Next year, you'll be \{age + 1}.");
    }

    public static StringTemplate.Processor<String, RuntimeException> DOUBLE_BRACES =
            (StringTemplate template) -> {
                var result = new StringBuilder();
                for (int i = 0; i < template.fragments().size(); i++) {
                    result.append(template.fragments().get(i));

                    if (i < template.values().size()) {
                        result.append("[[");
                        result.append("" + template.values().get(i));
                        result.append("]]");
                    }
                }
                return result.toString();
            };


    public static StringTemplate.Processor<String, RuntimeException> DOUBLE_BRACES_IMP =
            template -> {
                var convertedValues = template.values().stream().map(value -> "[[" + value + "]]").toList();

                return StringTemplate.interpolate(template.fragments(), convertedValues);
            };


    public static StringTemplate.Processor<String, RuntimeException> enclose(String left, String right) {
        return template -> {
            var convertedValues = template.values().stream().map(value -> left + value + right).toList();

            return StringTemplate.interpolate(template.fragments(), convertedValues);
        };
    }

    public static StringTemplate.Processor<String, RuntimeException> f =
            template -> {
                return StringTemplate.interpolate(template.fragments(), template.values());
            };
}
