package b_slides.java17.syntax.records;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RecordJSONExampleTest {

	final ObjectMapper mapper = new ObjectMapper()
		      .enable(SerializationFeature.INDENT_OUTPUT);

	
	@Test
	void serializeRecord() throws Exception {
	    // Given
	    var person = new Person(
	            "John",
	            "Doe",
	            "USA",
	            new Date(981291289182L),
	            List.of("Speaker")
	    );

	    var json = """
	            {
	              "first_name" : "John",
	              "last_name" : "Doe",
	              "address" : "USA",
	              "birthday" : 981291289182,
	              "achievements" : [ "Speaker" ]
	            }""";

	    // When
	    var serialized = mapper.writeValueAsString(person);

	    // Then
	    Assertions.assertThat(serialized).isEqualTo(json);
	}

	
	@Test
	void deserializeRecord() throws Exception {
		
	    // Given
	    var person = new Person(
	            "John",
	            "Doe",
	            "USA",
	            new Date(981291289182L),
	            List.of("Speaker")
	    );

	    var json = """
	            {
	              "first_name" : "John",
	              "last_name" : "Doe",
	              "address" : "USA",
	              "birthday" : 981291289182,
	              "achievements" : [ "Speaker" ]
	            }""";

	    // When
	    var deserialized = mapper.readValue(json, Person.class);

	    // Then
	    Assertions.assertThat(deserialized).isEqualTo(person);
	}
}
