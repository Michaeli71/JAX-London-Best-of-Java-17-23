package jep482_flexibile_constructor_bodies;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class PositiveBigIntegerOld1 extends BaseInteger
{
    public PositiveBigIntegerOld1(long value)
    {
        super(value);               // Potentially unnecessary work

        if (value <= 0)
            throw new IllegalArgumentException("non-positive value");
    }

    public static void main(String[] args) {
        new PositiveBigIntegerOld1(-4711);
    }
}