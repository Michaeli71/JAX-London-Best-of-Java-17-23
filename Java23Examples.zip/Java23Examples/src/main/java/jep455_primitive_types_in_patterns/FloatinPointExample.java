package jep455_primitive_types_in_patterns;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class FloatinPointExample {
    public static void main(String[] args) {
        float val = 1.0f;
        switch (val) {
            case 1.0f -> System.out.println("1.0");
            // case 0.999999999f -> System.out.println("0.9999..");
            default -> System.out.println("something else");
        }
    }
}
