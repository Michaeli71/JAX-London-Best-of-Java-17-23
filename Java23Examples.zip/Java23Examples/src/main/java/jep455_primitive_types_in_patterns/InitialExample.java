package jep455_primitive_types_in_patterns;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class InitialExample {

    record LogLevel(int severity) {}

    public static void main(String[] args) {

        LogLevel logLevel = new LogLevel(2);

        handlelLogLevel(logLevel);

        // WIth JEP 455
        handleLogLevelJep455(logLevel);
    }

    private static void handlelLogLevel(LogLevel logLevel) {
        String msg = switch (logLevel.severity())
        {
            case 0 -> "info";
            case 1 -> "warning";
            case 2 -> "error";
            default -> "unknown severity: " + logLevel.severity();
        };
        System.out.println(msg);
    }

    private static void handleLogLevelJep455(LogLevel logLevel) {
        String msg = switch (logLevel.severity()) {
            case 0 -> "info";
            case 1 -> "warning";
            case 2 -> "error";
            // JEP 455
            case int severity -> "unknown severity: " + severity;
        };
        System.out.println(msg);
    }
}
