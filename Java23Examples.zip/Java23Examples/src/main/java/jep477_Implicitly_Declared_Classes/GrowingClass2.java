package jep477_Implicitly_Declared_Classes;

import java.util.List;

import static java.io.IO.*;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class GrowingClass2
{
    void main()
    {
        String name = readln("Please enter your name: ");

        var authors = List.of("Tim", "Tom", "Mike", "Michael");
        for (var author_name : authors)
        {
            if (name.equalsIgnoreCase(author_name))
            {
                println(name + " you are registered as author!");
            }
            else
            {
                println(author_name + ": " + author_name.length());
            }
        }
    }
}