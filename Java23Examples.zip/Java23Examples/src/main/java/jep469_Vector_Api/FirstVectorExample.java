package jep469_Vector_Api;

import jdk.incubator.vector.IntVector;

import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class FirstVectorExample {
    public static void main(final String[] args) {

        int[] a = {1, 2, 3, 4, 5, 6, 7, 8};
        int[] b = {1, 2, 3, 4, 5, 6, 7, 8};

        var result1 = performScalarAddition(a, b);
        System.out.println("result using scalar calculation: " + Arrays.toString(result1));

        var result2 = performVectorAddition(a, b);
        System.out.println("result using Vector API: " + Arrays.toString(result2));
    }

        private static int[] performScalarAddition(int[] a, int[] b)
        {
            int[] c = new int[a.length];

            for (int i = 0; i < a.length; i++)
            {
                c[i] = a[i] + b[i];
            }

            return c;
        }

    private static int[] performVectorAddition(int[] a, int[] b)
    {
        int[] c = new int[a.length];

        IntVector vectorA = IntVector.fromArray(IntVector.SPECIES_256, a, 0);
        IntVector vectorB = IntVector.fromArray(IntVector.SPECIES_256, b, 0);

        IntVector vectorC = vectorA.add(vectorB); // var vectorC = vectorA.mul(vectorB);
        vectorC.intoArray(c, 0);

        return c;
    }
}
