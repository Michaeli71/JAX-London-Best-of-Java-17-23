package jep481_Scoped_Values.advanced_example;

import java.time.ZonedDateTime;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class ScopedValuesExample
{
    public static final ScopedValue<User> LOGGED_IN_USER =
                                          ScopedValue.newInstance();
    public static final ScopedValue<ZonedDateTime> REQUEST_TIME =
                                                   ScopedValue.newInstance();

    public static final Controller controller = 
                                   createController(new Service());
    
    private static Controller createController(final Service service) 
    {
        return new Controller(service);
    }

    // ...
    public static void main(final String[] args) throws Exception
    {
        // Simulate Requests
        for (String name : List.of("ATTACKER", "ADMIN"))
        {
            var user = new User(name, name.toLowerCase());
            ScopedValue.where(LOGGED_IN_USER, user).
                    where(REQUEST_TIME, ZonedDateTime.now()).
                    run(controller::consumingMethod);

            // Shortccut: where() + run(), aber nur eine Belegung
            ScopedValue.runWhere(LOGGED_IN_USER, user,
                    controller::consumingMethod);

            String answer = ScopedValue.where(LOGGED_IN_USER, user).
                    call(() -> controller.process());
            System.out.println(answer);
        }

        // Außerhalb des Scopes ist die Variable "unbound"
        System.out.print("Outside bounded scope ");
        System.out.println("isBound(): " + LOGGED_IN_USER.isBound());
    }
}